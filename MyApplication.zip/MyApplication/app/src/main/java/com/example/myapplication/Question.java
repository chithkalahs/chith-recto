package com.example.myapplication;

class Question{
    private int question_number;
    private String question;
    private String options;
    private String correct_answer;
    private String getCorrect_answer_option;

    public int getQuestion_number() {
        return question_number;
    }

    public void setQuestion_number(int question_number) {
        this.question_number = question_number;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public String getCorrect_answer() {
        return correct_answer;
    }

    public void setCorrect_answer(String correct_answer) {
        this.correct_answer = correct_answer;
    }

    public String getGetCorrect_answer_option() {
        return getCorrect_answer_option;
    }

    public void setGetCorrect_answer_option(String getCorrect_answer_option) {
        this.getCorrect_answer_option = getCorrect_answer_option;
    }
}

