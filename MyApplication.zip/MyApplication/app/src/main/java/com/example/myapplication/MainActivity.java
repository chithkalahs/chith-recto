package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Question> mQuestionArrayList= new ArrayList<>();
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    getQuestionList();
    setUIRef();
    }

    private void setUIRef() {
        RecyclerView recyclerView=findViewById(R.id.myRecyclerView);
        MyRecyclerViewAdapter myRecyclerViewAdapter=new MyRecyclerViewAdapter(mQuestionArrayList);
        recyclerView.setAdapter(myRecyclerViewAdapter);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(MainActivity.this,RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void getQuestionList() {
        String myJSONStr= loadJsonDataFromAssets();
        try {
            JSONObject rootJsonObject= new JSONObject(myJSONStr);
            JSONArray questionJsonArray= rootJsonObject.getJSONArray("questions");
            for (int i=0;i<questionJsonArray.length();i++){
                Question aQuestion=new Question();
                JSONObject jsonObject=questionJsonArray.getJSONObject(i);

                aQuestion.setQuestion_number(jsonObject.getInt("question_number"));
                aQuestion.setQuestion(jsonObject.getString("question"));
                aQuestion.setOptions(jsonObject.getString("options"));
                aQuestion.setCorrect_answer(jsonObject.getString("correct_answer"));
                aQuestion.setGetCorrect_answer_option(jsonObject.getString("correct_answer_option"));

                mQuestionArrayList.add(aQuestion);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String loadJsonDataFromAssets() {
        String json=null;
        try {
            InputStream inputStream=getAssets().open("recto007.json");
            int size=inputStream.available();
            byte[] buffer=new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json=new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return json;
    }
}




