package com.example.myapplication;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyViewHolder>{
    private ArrayList<Question> mQuestionList =new ArrayList<>();

    public MyRecyclerViewAdapter(ArrayList<Question> questionArrayList) {
        this.mQuestionList = questionArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View questionRow= LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        MyViewHolder myViewHolder=new MyViewHolder(questionRow);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String question_number="question_number:" +mQuestionList.get(position).getQuestion_number();
        holder.question_number.setText(question_number);

        String question="question:" +mQuestionList.get(position).getQuestion();
        holder.question.setText(question);

        String options="options:" +mQuestionList.get(position).getOptions();
        holder.options.setText(options);

        String correct_answer="correct_answer:" +mQuestionList.get(position).getCorrect_answer();
        holder.correct_answer.setText(correct_answer);

        String correct_option_number="correct_option_number:" +mQuestionList.get(position).getGetCorrect_answer_option();
        holder.correct_option_number.setText(correct_option_number);
    }

    @Override
    public int getItemCount() {
        return mQuestionList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView question_number;
        private TextView question;
        private TextView options;
        private TextView correct_answer;
        private TextView correct_option_number;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            question_number=itemView.findViewById(R.id.question_number);
            question=itemView.findViewById(R.id.question);
            options=itemView.findViewById(R.id.options);
            correct_answer=itemView.findViewById(R.id.correct_answer);
            correct_option_number=itemView.findViewById(R.id.correct_option_number);
        }
    }
}
